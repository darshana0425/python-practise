#Program: GUI demo 
#Author: Umesh Poudel
#Date: 4th Sep 2022

from tkinter import *;

    
root = Tk()
root.title('My Python Application')
root.geometry('400x200')


root.mainloop();

#Program: Basic Calculation 
#Author: Umesh Poudel
#Date: 4th Sep 2022

from tkinter import *;
from tkinter import messagebox

def clear():    
    #labelDisplay.configure(text="")      
    labelDisplay['text']="";
    num1.delete(0,END);
    num2.delete(0,END) 
    

def addNumber():
    #must provide inputs
    if(num1.get()=="" or num2.get()==""):
       messagebox.showinfo("Invalid inputs","Please provide valid inputs")
       return
    
    labelDisplay['text'] = int(num1.get()) + int(num2.get())

root = Tk()
root.title('Simple Calculator')
root.geometry('400x200')

label1=Label(text='Enter first number:')
num1=Entry()

label2=Label(text='Enter second number:')
num2=Entry()

btnAdd=Button(text='Add',command=addNumber)
btnClear=Button(text='Clear',command=clear)

labelDisplay=Label(font=('Courier 20'),fg='red',height=2)
num2=Entry()


label1.grid(row=0,column=0);
num1.grid(row=0,column=1);

label2.grid(row=1,column=0);
num2.grid(row=1,column=1);

labelDisplay.grid(row=2,column=0,columnspan=2);

btnAdd.grid(row=3,column=0,padx='20',sticky='E');
btnClear.grid(row=3,column=1,sticky='W');

root.mainloop();

#Program: Basic Calculation 
#Author: Umesh Poudel
#Date: 4th Sep 2022

from tkinter import *;
from tkinter import messagebox

def showMessage():
    messagebox.showinfo(title='Information',message='This is a sample message.')
    
root = Tk()
root.title('Tkinter MessageBox')
root.geometry('400x200')

btnInfo=Button(text='Show Info',command=showMessage)

btnInfo.grid(row=0,column=0);

root.mainloop();

#Program: Message boxes
#Author: Umesh Poudel
#Date: 4th Sep 2022

from tkinter import *
from tkinter import messagebox

def info():
    messagebox.showinfo(title='Information',message='This is a sample message.')

def warning():
    messagebox.showwarning(title='Warning',message='This is a sample message.')

def yesno():
    messagebox.askyesno(title='Confirmation',message='This is a sample message.')    

def retrycancel():
    messagebox.askretrycancel(title='Retry',message='This is a sample message.')

    
root = Tk()
root.title('Tkinter MessageBox')
root.geometry('400x200')

btnInfo=Button(text='Show Info',command=info)
btnWarning=Button(text='Show Warning',command=warning)
btnYesNo=Button(text='Ask Yes-NO',command=yesno)
btnRetryCancel=Button(text='Retry Cancel',command= retrycancel)

btnInfo.grid(row=0,column=0);
btnWarning.grid(row=1,column=0);
btnYesNo.grid(row=2,column=0);
btnRetryCancel.grid(row=3,column=0);

root.mainloop();
